﻿using Microsoft.AspNetCore.Mvc;
using StudentDataApi.Data;
using StudentDataApi.Logics;
using StudentDataApi.Models;
using System.Net;
using Microsoft.Extensions.Configuration;
namespace StudentDataApi.Controllers
{
 
    public class StudentController : Controller
    {
       
        private readonly HttpHelper httpHelper;
        private IConfiguration configuration { get; }
        ConnectionDbContext db;
        public StudentController(HttpHelper _httpHelper, IConfiguration _configuration, ConnectionDbContext _db)
        {
            httpHelper = _httpHelper;
            configuration = _configuration;
            db = _db;
        }


        public ActionResult Index()
        {
            return View();
        }

       // [HttpPost]
       //// [Route("api/Create")]
       // public ActionResult Index(IFormCollection fc)
       // {
       //    Student student = new Student();
       //     student.Email = fc["Email"];
       //     student.FullName = fc["FullName"];
       //     student.Address = fc["Address"];      
       //     db.studentDetail.Add(student);
       //     db.SaveChanges();
       //     return RedirectToAction("GetStudent");
       // }

        //[HttpGet]
        
        //public ActionResult GetStudent()
        //{
        //    List<Student> student = new List<Student>();
        //    student = db.studentDetail.ToList();
        //    return View(student);
        //}
        HttpClient httpClient = new HttpClient();
        public List<Student> student { get; set; }
        [HttpGet]
        public ActionResult GetStudent()
        {
           //var url = configuration["MyApi: DefaultApi"];
            httpClient.BaseAddress = new Uri("https://localhost:7174/api/Values");
            var response = httpClient.GetAsync("Values");
            response.Wait();
            var test = response.Result;
            if (test.IsSuccessStatusCode)
            {
                var display = test.Content.ReadAsAsync<List<Student>>();
                display.Wait();
                student = display.Result;
            }
            return View(student);
        }
        
        public ActionResult AddStudent()
        {
            return View();
        }


       
        [HttpPost]
        public ActionResult AddStudent(IFormCollection fc)
        {
            //var url = configuration["MyApi: DefaultApi"];
            Student student = new Student();
            student.FullName = fc["FullName"];
            student.Email = fc["Email"];
            student.Address = fc["Address"];
            if(httpHelper.PostData(student, "https://localhost:7174/api/Values"))
            {
                return RedirectToAction("GetStudent");   
            }
            else
            {
                return View();
            }
        }
        public ActionResult EditStudent()
        {
            return View();
        }

        [HttpGet]
        public ActionResult EditStudent(int? id)
        {
            Student student = new Student();
            student = db.studentDetail.FirstOrDefault(p=>p.Id==id);
            return View(student);
        }

        [HttpPost]
        public ActionResult EditStudent(IFormCollection fc)
        {
            Student student = new Student();
            student.FullName = fc["FullName"];
            student.Email = fc["Email"];
            student.Address = fc["Address"];
        
            if (httpHelper.PutData(student, $"https://localhost:7174/api/Values/{fc["Id"]}"))
            {
                return RedirectToAction("GetStudent");
            }
            else
            {
                return View();
            }
        }
        public ActionResult DeleteStudent()
        {
            return View();
        }


        [HttpGet]
        public ActionResult DeleteStudent(int? id)
        {
            Student student = new Student();
            student = db.studentDetail.FirstOrDefault(p => p.Id == id);
            return View(student);
        }

       [HttpPost]
        public ActionResult DeleteStudent(IFormCollection fc)
        {
            if (httpHelper.DeleteData($"https://localhost:7174/api/Values/{fc["Id"]}"))
            {
                return RedirectToAction("GetStudent");
            }
            else
            {
                return View();
            }

        }
    }
}
